package com.mock.agent.util;

public class OutTime {
	private long start;

	public OutTime() {
		start = System.currentTimeMillis();
	}

	public void endMethod(String className, String methodName,String methodDesc) {
		long end = System.currentTimeMillis();
		System.out.println(className.replace("/", ".")+"."+methodName+methodDesc+"--time--【"+ (end - start) + "】毫秒");
	}

}
