package com.mock.agent.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class FileUtil {

	public static void writeString(String path, boolean isWrite, String... str) {
		try (FileWriter fw = new FileWriter(new File(path), isWrite)) {
			for (String ss : str) {
				fw.write(ss);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void writeStringLoad(String path, String... str) {
		writeString(path, true, str);
	}

	public static void writeByteArray(String path, byte[] byteArray) {
		try (FileOutputStream fos = new FileOutputStream(path)) {
			fos.write(byteArray);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}
