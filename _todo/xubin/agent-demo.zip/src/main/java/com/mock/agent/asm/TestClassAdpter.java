package com.mock.agent.asm;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.commons.AnalyzerAdapter;
import org.objectweb.asm.commons.LocalVariablesSorter;

import com.mock.agent.util.OutTime;

public class TestClassAdpter extends ClassVisitor implements Opcodes {
	private String className;
	private String methodName;
	private String methodDesc;

	private boolean isInterface;

	private boolean isAnno = false;

	public TestClassAdpter(ClassVisitor cv) {
		super(ASM5, cv);
	}

	@Override
	public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
		cv.visit(version, access, name, signature, superName, interfaces);
		className = name;
		isInterface = (access & ACC_INTERFACE) != 0;
	}

	@Override
	public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
		AnnotationVisitor visitAnnotation = cv.visitAnnotation(desc, visible);
		isAnno = true;
		return visitAnnotation;
	}

	@Override
	public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
		MethodVisitor mv = cv.visitMethod(access, name, desc, signature, exceptions);
		// 分别的意思是 不是接口类，非"<init>"方法非lamba表达式，存在注解类的类，这里是可以过滤类上面的参数的，方便哪些类的方法需要统计哪些不需要
		if (!isInterface && mv != null && !name.equals("<init>") && !name.startsWith("lambda") && isAnno) {
			methodName = name;
			TestMethodAdapter atma = new TestMethodAdapter(mv);
			atma.setAa(new AnalyzerAdapter(className, access, name, desc, atma));
			atma.setLvs(new LocalVariablesSorter(access, desc, atma.getAa()));
			return atma.getLvs();
		}
		return mv;
	}

	class TestMethodAdapter extends MethodVisitor {
		private AnalyzerAdapter aa;
		private LocalVariablesSorter lvs;
		private int durationId = -1;
		private int maxStack;

		public AnalyzerAdapter getAa() {
			return aa;
		}

		public void setLvs(LocalVariablesSorter lvs) {
			this.lvs = lvs;
		}

		public void setAa(AnalyzerAdapter aa) {
			this.aa = aa;
		}

		public LocalVariablesSorter getLvs() {
			return lvs;
		}

		public TestMethodAdapter(MethodVisitor mv) {
			super(ASM5, mv);
		}

		@Override
		public void visitParameter(String name, int access) {
			super.visitParameter(name, access);
		}

		@Override
		public void visitCode() {
			mv.visitCode();
			durationId = lvs.newLocal(Type.getType(OutTime.class));
			mv.visitTypeInsn(NEW, "com/mock/agent/util/OutTime");
			mv.visitInsn(DUP);
			mv.visitMethodInsn(INVOKESPECIAL, "com/mock/agent/util/OutTime", "<init>", "()V", false);
			mv.visitVarInsn(ASTORE, durationId);
			maxStack = 4;
		}

		@Override
		public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf) {
			if (isAnno) {
				methodDesc = desc;
			}
			super.visitMethodInsn(opcode, owner, name, desc, itf);
		}

		@Override
		public void visitInsn(int opcode) {
			if ((opcode >= IRETURN && opcode <= RETURN) || opcode == ATHROW) {

				mv.visitVarInsn(ALOAD, durationId);
				mv.visitLdcInsn(className);
				mv.visitLdcInsn(methodName);
				mv.visitLdcInsn(methodDesc);
				mv.visitMethodInsn(INVOKEVIRTUAL, "com/mock/agent/util/OutTime", "endMethod",
						"(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", false);
				maxStack = Math.max(aa.stack.size() + 4, maxStack);
			}
			mv.visitInsn(opcode);
		}

		@Override
		public void visitMaxs(int maxStack, int maxLocals) {
			super.visitMaxs(Math.max(maxStack, this.maxStack), maxLocals);
		}
	}
}
