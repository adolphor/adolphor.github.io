package com.mock.agent;

import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import java.security.ProtectionDomain;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;

import com.mock.agent.asm.TestClassAdpter;

public class TestAgent {
	public static void youdemeide(Instrumentation inst) {
		// 返回当前JVM配置是否支持 setting a native method prefix 。
		boolean nativeMethodPrefixSupported = inst.isNativeMethodPrefixSupported();
		// 返回当前JVM配置是否支持对类进行重新传输。
		boolean retransformClassesSupported = inst.isRetransformClassesSupported();
		// 返回当前的JVM配置是否支持重新定义类。
		boolean redefineClassesSupported = inst.isRedefineClassesSupported();
		System.out.println(nativeMethodPrefixSupported);
		System.out.println(retransformClassesSupported);
		System.out.println(redefineClassesSupported);
	}

	public static void asm(Instrumentation inst) throws UnmodifiableClassException {
		inst.addTransformer((ClassLoader loader, String className, Class<?> classBeingRedefined,
				ProtectionDomain protectionDomain, byte[] classfileBuffer) -> {
			if (classBeingRedefined.getName().startsWith("com.joyoung.")
					|| classBeingRedefined.getName().startsWith("com.xiaospace.")) {
				ClassReader cr = new ClassReader(classfileBuffer);
				ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
				cr.accept(new TestClassAdpter(cw), ClassReader.EXPAND_FRAMES);
				return cw.toByteArray();
			}
			return null;
		}, true);

		Class[] allLoadedClasses = inst.getAllLoadedClasses();
		for (int i = 0; i < allLoadedClasses.length; i++) {
			Class classes = allLoadedClasses[i];
			if (classes.getName().startsWith("com.joyoung.") || classes.getName().startsWith("com.xiaospace.")) {
				inst.retransformClasses(classes);
			}
		}
	}

	public static void agentmain(String agentArgs, Instrumentation inst) throws UnmodifiableClassException {
		asm(inst);
	}
}
